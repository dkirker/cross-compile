========================================================================
       CONSOLE APPLICATION : espeak
========================================================================

This is a Virtual C++ project to make a command-line version
of eSpeak for Windows.

Copy the source files from the Linux "src" directory into this
"src" directory, EXCEPT for speech.h.   Keep the original Windows
command-line version of speech.h.

